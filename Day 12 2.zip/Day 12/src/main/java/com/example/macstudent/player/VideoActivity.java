package com.example.macstudent.player;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoActivity extends AppCompatActivity {

    VideoView vplayer;
    MediaController mediaController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        vplayer = findViewById(R.id.videoPlayer);

        vplayer.setVideoURI(Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.toronto));
        mediaController = new MediaController(this);
        mediaController.show(300);
        vplayer.setMediaController(mediaController);
        vplayer.start();
    }
}
