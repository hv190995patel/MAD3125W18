package com.example.macstudent.day1thunderstrom;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin;
    Button btnRegister;
    EditText edtUserName;
    EditText edtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button)findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = (Button)findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtUserName = (EditText)findViewById(R.id.edtUserName);
        edtPassword = (EditText)findViewById(R.id.edtPassword);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId())
        {
            String uname = edtUserName.getText().toString();
            String password = edtPassword.getText().toString();

            if(uname.equals("test") && password.equals("test"))
            {
                Toast.makeText(this, "Login Successful",Toast.LENGTH_LONG).show();
                Intent homeIntent = new Intent(this,HomeActivity.class);
                startActivity(homeIntent);
            }

        }
        else  if(view.getId() == btnRegister.getId())
        {
            Toast.makeText(this, "Registered", Toast.LENGTH_SHORT).show();
            Intent registerIntent = new Intent(this, RegisterActivity.class);
            startActivity(registerIntent);
        }
    }
}
