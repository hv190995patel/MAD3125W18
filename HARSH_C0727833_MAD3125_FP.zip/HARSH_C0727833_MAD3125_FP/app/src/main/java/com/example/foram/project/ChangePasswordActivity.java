package com.example.foram.project;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ChangePasswordActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnChngPswd;
   // EditText oldPswd;
    //EditText newPswd;
    //EditText cnfrmPswd;
    DBHelper DBHelper;
    SQLiteDatabase projectDB;
    String OldPwd,newpwd,confirmpwd;
    TextView chOldPwd,chPwd,chconfirPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        btnChngPswd = (Button) findViewById(R.id.btnChngPswd);
        btnChngPswd.setOnClickListener(this);

        chOldPwd = (EditText) findViewById(R.id.odl_pswd);
        chPwd = (EditText) findViewById(R.id.new_pswd);
        chconfirPwd = (EditText) findViewById(R.id.confirm_pswd);

        DBHelper = new DBHelper(this);
        displayData();
    }

    @Override
    public void onClick(View view) {

        if (view.getId() == btnChngPswd.getId())
        {
            insertUser();
          //  ChangePassword();

           /* Intent homeIntent = new Intent(this, HomeActivity.class);
            startActivity(homeIntent);*/
        }
    }

    private void insertUser(){
        OldPwd = chOldPwd.getText().toString();
        newpwd = chPwd.getText().toString();
        confirmpwd = chconfirPwd.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Password", newpwd);

        try{
            SharedPreferences sp = getSharedPreferences("com.example.foram.project.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");

            projectDB = DBHelper.getWritableDatabase();
            projectDB.update("UserInfo", cv, "Email=\""+data+"\"",null);

            Log.v("Update record","Successful");

            Toast.makeText(this,"Change Password Successfully", Toast.LENGTH_LONG).show();
            Intent home1Intent = new Intent(getApplicationContext(),HomeActivity.class);
            startActivity(home1Intent);

        }catch (Exception e){
            Log.e("Update User",e.getMessage());
        }
        projectDB.close();
    }

    private void displayData(){
        try{
            SharedPreferences sp = getSharedPreferences("com.example.foram.project.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");

            projectDB= DBHelper.getReadableDatabase();
            String columns[] = {"Password"};

            String query = "SELECT * FROM UserInfo where Email='" + data + "' ";
            Cursor cursor = projectDB.rawQuery(query, null);

            while (cursor.moveToNext()){
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                chOldPwd.setText(password);
            }

        }catch (Exception e){
            Log.e("RegisterActivity : ","Unable to fetch the records");
        }
        projectDB.close();
    }
    /*private  void ChangePassword()
    {
        String oldPass = oldPswd.getText().toString();
        String newPass = newPswd.getText().toString();
        String cnfrmPass = cnfrmPswd.getText().toString();

       ContentValues cv = new ContentValues();

        cv.put("Password", cnfrmPass);


        try{
            SharedPreferences sp = getSharedPreferences("com.example.foram.project.shared", Context.MODE_PRIVATE);
            String data = sp.getString("Password","Data Missing");


            projectDB = DBHelper.getWritableDatabase();

            projectDB.update("UserInfo", cv, "Password=\""+data+"\"",null);

            Log.v("Password Update","Successful");

            Toast.makeText(this,"Password Updated Successfully", Toast.LENGTH_LONG).show();


        }
        catch (Exception e){
            Log.e("Insert valid password",e.getMessage());

        }
        projectDB.close();
    }*/
}

