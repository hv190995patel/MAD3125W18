package com.example.foram.project;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        SharedPreferences sp = getSharedPreferences("com.example.foram.project.shared", Context.MODE_PRIVATE);
        String carNumber = sp.getString("CarPlate","Data Missing");
        String company =  sp.getString("Company", "Data Missing");
        String payment =  sp.getString("Payment", "Data Missing");
        String lot =  sp.getString("Lot", "Data Missing");
        String spot =  sp.getString("Spot", "Data Missing");
        String dateTime = sp.getString("DateTime", "Data Missing");
        String amount =  String.valueOf(sp.getInt("Amount", 0));

        TextView txtCarPlate = (TextView) findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(carNumber);

        TextView txtComp = (TextView) findViewById(R.id.txtCompany);
        txtComp.setText(company);

        TextView txtPay = (TextView) findViewById(R.id.txtPayment);
        txtPay.setText(payment);

        TextView txtLot = (TextView) findViewById(R.id.txtLot);
        txtLot.setText(lot);

        TextView txtSpot = (TextView) findViewById(R.id.txtSpot);
        txtSpot.setText(spot);

        TextView txtDateTime = (TextView) findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime);

        TextView txtAmount = (TextView) findViewById(R.id.txtAmount);
        txtAmount.setText(amount);
    }
}
