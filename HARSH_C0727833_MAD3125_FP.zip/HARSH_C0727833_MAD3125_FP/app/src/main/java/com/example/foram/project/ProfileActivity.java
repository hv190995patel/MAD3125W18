package com.example.foram.project;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnUpdate;
    EditText upName,upEmail,upPhone;
    TextView uppwd;
    DBHelper DBHelper;
    SQLiteDatabase projectDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        btnUpdate = (Button) findViewById(R.id.btnupdate);
        btnUpdate.setOnClickListener(this);

        uppwd = (TextView) findViewById(R.id.uppwd);
        uppwd.setOnClickListener(this);

        upName = (EditText) findViewById(R.id.upName);
        upEmail = (EditText) findViewById(R.id.upEmail);
        upPhone = (EditText) findViewById(R.id.upPhone);

        DBHelper = new DBHelper(this);
        displayData();
    }

    @Override
    public void onClick(View view)
    {
        if (view.getId() == btnUpdate.getId()) {

            insertUser();



        } else if (view.getId() == uppwd.getId()) {

            Intent changepwdIntent = new Intent(this, ChangePasswordActivity.class);
            startActivity(changepwdIntent);
        }

    }

    private void insertUser(){

        String name = upName.getText().toString();
        String phone = upPhone.getText().toString();
        String email = upEmail.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Name", name);
        cv.put("Phone", phone);
        cv.put("Email", email);


        try{
            SharedPreferences sp = getSharedPreferences("com.example.foram.project.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");


            projectDB = DBHelper.getWritableDatabase();

            projectDB.update("UserInfo", cv, "Email=\""+data+"\"",null);

            Log.v("Insert record","Successful");

            Toast.makeText(this,"Updated Successfully", Toast.LENGTH_LONG).show();


        }
        catch (Exception e){
            Log.e("Insert User",e.getMessage());

        }
        projectDB.close();
    }


    private void displayData(){

        try{

            SharedPreferences sp = getSharedPreferences("com.example.foram.project.shared", Context.MODE_PRIVATE);
            String data = sp.getString("username","Data Missing");

            projectDB = DBHelper.getReadableDatabase();

            String columns[] = {"Name", "Phone", "Email"};


            String query = "SELECT Name,Phone,Email FROM UserInfo where Email='" + data + "' ";
            Cursor cursor = projectDB.rawQuery(query, null);



            while (cursor.moveToNext()){
                String name = cursor.getString(cursor.getColumnIndex("Name"));
                upName.setText(name);

                String email = cursor.getString(cursor.getColumnIndex("Email"));
                upEmail.setText(email);

                String phone = cursor.getString(cursor.getColumnIndex("Phone"));
                upPhone.setText(phone);

                String userInfo = name + "\n" + phone + "\n"+ email + "\n" ;


                Toast.makeText(this,userInfo, Toast.LENGTH_LONG).show();

            }


        }catch (Exception e){
            Log.e("RegisterActivity : ", "Unable to fetch the records");
        }

        projectDB.close();

    }
}