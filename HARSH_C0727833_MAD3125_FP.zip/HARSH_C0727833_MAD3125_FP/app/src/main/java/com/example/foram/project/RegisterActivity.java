package com.example.foram.project;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

      Button btnSubmit;
      DBHelper dbHelper;
      SQLiteDatabase projectDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnSubmit = (Button)findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {

        if(view.getId() == btnSubmit.getId()){

            insertUser();
            displayData();

            Intent submitIntent = new Intent(this, HomeActivity.class);
            startActivity(submitIntent);

        }
    }

    private  void insertUser() {
        EditText edtName = (EditText) findViewById(R.id.edtName);
        EditText edtEmail = (EditText) findViewById(R.id.edtEmail);
        EditText edtPassword = (EditText) findViewById(R.id.edtPassword);
        EditText edtPhone = (EditText) findViewById(R.id.edtPhone);
        EditText edtCarNumber = (EditText) findViewById(R.id.edtCarNumber);

        String name = edtName.getText().toString();
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();
        String phone = edtPhone.getText().toString();
        String carnumber = edtCarNumber.getText().toString();

        ContentValues cv = new ContentValues();
        cv.put("Name", name);
        cv.put("Email", email);
        cv.put("Password", password);
        cv.put("Phone", phone);
        cv.put("CarNumber", carnumber);

        try {
            projectDB = dbHelper.getWritableDatabase();
            projectDB.insert("UserInfo", null, cv);
            Log.v("Insert record", "Successful");


        }
        catch (Exception e) {

            Log.e("Insert User",e.getMessage());
        }
        projectDB.close();
    }

    private void displayData()
    {
        try
        {
            projectDB = dbHelper.getReadableDatabase();

            String columns[] = {"Name", "Email", "Password", "Phone", "CarNumber"};

            Cursor cursor = projectDB.query("UserInfo", columns, null, null, null, null, null);

            while (cursor.moveToNext())
            {
                String name = cursor.getString(cursor.getColumnIndex("Name"));
                String email = cursor.getString(cursor.getColumnIndex("Email"));
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                String phone = cursor.getString(cursor.getColumnIndex("Phone"));
                String carPlateNumber = cursor.getString(cursor.getColumnIndex("CarNumber"));

                String userInfo = name + "\n" + email + "\n" + password + "\n" + phone + "\n" + carPlateNumber;

                Toast.makeText(this, userInfo, Toast.LENGTH_LONG).show();
            }
        }
        catch(Exception e)
        {
            Log.e("RegisterActivity : ", "Unable to fetch the records" );
        }
    }
}
