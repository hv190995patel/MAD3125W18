package com.example.macstudent.day1thunderstrom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Calendar;
import java.util.Date;

public class ParkingActivity extends AppCompatActivity implements View.OnClickListener,AdapterView.OnItemSelectedListener {

    RadioButton rdoHalf,rdoOne,rdoTwo,rdoThree;
    TextView txtAmount, txtDateTime;
    int parkingRate[] = {5,10,20,35};
    String lots[] = {"A","B","C","D","E"};
    Spinner spinLot;

    String spots[] = {"F","G","H","I"};
    Spinner spinSpot;
    Spinner spinCompany;
    String PaymentMethos[] = {"Debit","Credit","Cash"};
    Spinner spinpayment;

    int logos[] = {R.drawable.img_bmw,R.drawable.img_audi};
    String companyNames[] = {"BMW","Audi"};

    String lot,spot,carplate,payment,dateTime,company;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking);

        rdoHalf = (RadioButton) findViewById(R.id.rdoHalfHour);
        rdoHalf.setOnClickListener(this);

        rdoOne = (RadioButton) findViewById(R.id.rdoOneHour);
        rdoOne.setOnClickListener(this);

        rdoTwo= (RadioButton) findViewById(R.id.rdoTwoHour);
        rdoTwo.setOnClickListener(this);

        rdoThree = (RadioButton) findViewById(R.id.rdoThreeHour);
        rdoThree.setOnClickListener(this);

        txtAmount = (TextView) findViewById(R.id.txtAmount);
        txtAmount.setText("$" + String.valueOf(parkingRate[0]));

        txtDateTime = (TextView) findViewById(R.id.txtDateTime);
        Date dt = Calendar.getInstance().getTime();
        txtDateTime.setText(dt.toString());

        spinLot = (Spinner)findViewById(R.id.spiLot);
        ArrayAdapter adapLot = new ArrayAdapter(this,android.R.layout.simple_spinner_item,lots);
        adapLot.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinLot.setAdapter(adapLot);

        spinSpot = (Spinner)findViewById(R.id.spiSpot);
        ArrayAdapter adapSpot = new ArrayAdapter(this,android.R.layout.simple_spinner_item,spots);
        adapLot.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinSpot.setAdapter(adapSpot);

        spinpayment = (Spinner)findViewById(R.id.spiPayment);
        ArrayAdapter adapPayment = new ArrayAdapter(this,android.R.layout.simple_spinner_item,PaymentMethos);
        adapPayment.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinpayment.setAdapter(adapPayment);

        spinCompany = (Spinner)findViewById(R.id.spiCompany);
        carAdapter carAdapter = new carAdapter(getApplicationContext(),logos,companyNames);
        spinCompany.setAdapter(carAdapter);
        spinCompany.setOnItemSelectedListener(this);

    }

    @Override
    public void onClick(View view) {
        if (rdoHalf.isChecked()) {
            txtAmount.setText("$" + String.valueOf(parkingRate[0]));
        } else if(rdoOne.isChecked()) {
            txtAmount.setText("$" + String.valueOf(parkingRate[1]));
        } else if(rdoTwo.isChecked()) {
            txtAmount.setText("$" + String.valueOf(parkingRate[2]));
        } else if(rdoThree.isChecked()) {
            txtAmount.setText("$" + String.valueOf(parkingRate[3]));
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
    if(adapterView.getId() == spinLot.getId()) {
        Toast.makeText(this,lots[position],Toast.LENGTH_LONG).show();
        lot = lots[position];
    } else if(adapterView.getId() == spinSpot.getId()) {
        Toast.makeText(this,spots[position],Toast.LENGTH_LONG).show();
        spot = spots[position];
    } else if(adapterView.getId() == spinpayment.getId()) {
        Toast.makeText(this,PaymentMethos[position],Toast.LENGTH_LONG).show();
        payment = PaymentMethos[position];
    } else if (adapterView.getId() == spinCompany.getId()){
        Toast.makeText(this,companyNames[position],Toast.LENGTH_LONG).show();
        company = companyNames[position];
    }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
