package comd.example.macstudent.day1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.w3c.dom.Text;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin;
    Button btnResgister;
    EditText edtUsername;
    EditText edtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnResgister = (Button) findViewById(R.id.btnRegister);
        btnResgister.setOnClickListener(this);

        edtUsername = (EditText) findViewById(R.id.edtUserName);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
    }

    @Override
    public void onClick(View view) {
        String uname = edtUsername.getText().toString();
        String pwd = edtPassword.getText().toString();

        if (view.getId() == btnLogin.getId()) {
            Toast.makeText(this, uname + " " + pwd, Toast.LENGTH_LONG).show();
        }
        else if(view.getId() == btnResgister.getId()) {
            Toast.makeText(this, "Register Clicked", Toast.LENGTH_LONG).show();
        }
    }
}
